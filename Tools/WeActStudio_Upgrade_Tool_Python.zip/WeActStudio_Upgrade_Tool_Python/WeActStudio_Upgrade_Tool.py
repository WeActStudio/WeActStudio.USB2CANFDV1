import serial
import time
import os
import sys
import struct
from serial.tools import list_ports
from dataclasses import dataclass
import subprocess


class FPK_HeaderReader:
    FPK_HEAD_NAME_MAX_LEN = 4
    FPK_CONFIG_MAX_LEN = 4
    FPK_FIRMWARE_VERSION_MAX_LEN = 16
    FPK_USER_STRING_MAX_LEN = 16
    FPK_PART_NAME_MAX_LEN = 16

    FPK_HEAD_FORMAT = (
        f"<{FPK_HEAD_NAME_MAX_LEN}s"  # head_name[4]
        f"{FPK_CONFIG_MAX_LEN}s"  # config_info[4]
        f"{FPK_FIRMWARE_VERSION_MAX_LEN}s"  # fw_old_ver[16]
        f"{FPK_FIRMWARE_VERSION_MAX_LEN}s"  # fw_new_ver[16]
        f"{FPK_USER_STRING_MAX_LEN}s"  # user_string[16]
        f"{FPK_PART_NAME_MAX_LEN}s"  # part_name[16]
        "I"  # raw_size      uint32
        "I"  # pkg_size      uint32
        "I"  # timestamp     uint32
        "I"  # raw_crc32     uint32
        "I"  # pkg_crc32     uint32
        "I"  # head_crc32    uint32
    )

    FPK_HEAD_SIZE = 0

    def decode_c_str(self, data: bytes) -> str:
        """Decode C-style string to Python string"""
        return data.split(b"\x00")[0].decode("utf-8", errors="ignore").strip()

    def decode_version(self, data: bytes) -> str:
        """Decode version string"""
        v0 = data[0]
        v1 = data[1]
        v2 = data[2]
        v3 = data[3]
        b7 = data[7]
        b6 = data[6]
        b5 = data[5]
        b4 = data[4]
        return f"V{v0}.{v1}.{v2}.{v3}_{b7:02x}{b6:02x}{b5:02x}{b4:02x}"

    def read_fpk_header(self, file_path: str) -> dict:
        """Read FPK header from file"""
        with open(file_path, "rb") as f:
            head_bin = f.read(self.FPK_HEAD_SIZE)

        if len(head_bin) != self.FPK_HEAD_SIZE:
            raise ValueError(
                f"file {file_path} header size is {self.FPK_HEAD_SIZE} byte, but read {len(head_bin)} byte"
            )

        # Unpack binary data
        parts = struct.unpack(self.FPK_HEAD_FORMAT, head_bin)

        return {
            "head_name": self.decode_c_str(parts[0]),
            "config_info": parts[1].hex(),
            "fw_old_ver": self.decode_version(parts[2]),
            "fw_new_ver": self.decode_version(parts[3]),
            "user_string": self.decode_c_str(parts[4]),
            "part_name": self.decode_c_str(parts[5]),
            "raw_size": parts[6],
            "pkg_size": parts[7],
            "timestamp": time.strftime("%Y.%m.%d %H:%M:%S", time.localtime(parts[8])),
            "raw_crc32": f"0x{parts[9]:08X}",
            "pkg_crc32": f"0x{parts[10]:08X}",
            "head_crc32": f"0x{parts[11]:08X}",
            "header_len": self.FPK_HEAD_SIZE,
        }

    def __init__(self):
        """Initialize FPK header reader"""
        self.FPK_HEAD_SIZE = struct.calcsize(self.FPK_HEAD_FORMAT)


@dataclass(frozen=True)  # 冻结：禁止修改，保证常量安全
class WeActStudioDevice:
    """WeAct Studio Device Information"""

    id: str
    vid_pid: str
    cmd: bytes
    user_string: str


class WeActStudioDeviceInfo:
    USB2CANFD_V1 = WeActStudioDevice(
        id="AA", vid_pid="0x483:0x5740", cmd=b"X\r", user_string="USB2CANV1"
    )

    DISPLAYV1FS = WeActStudioDevice(
        id="AB",
        vid_pid="0x1A86:0xFE0C",
        cmd=b"\x41\xa5\xaa\x0a",
        user_string="DISPLAYV1FS",
    )

    PD_POWER_MINI_V1 = WeActStudioDevice(
        id="AC",
        vid_pid="0x1A86:0xFE0C",
        cmd=b"\x41\xa5\xaa\x0a",
        user_string="PDPOWERMINIV1",
    )

    DISPLAY096FS = WeActStudioDevice(
        id="AD",
        vid_pid="0x1A86:0xFE0C",
        cmd=b"\x41\xa5\xaa\x0a",
        user_string="DISPLAY096FS",
    )

    KEYBOARD_3_MINI = WeActStudioDevice(
        id="B0",
        vid_pid="0x1A86:0xFE0C",
        cmd=b"\x41\xa5\xaa\x0a",
        user_string="KEYBOARD3MINI",
    )

    POWER_MONITOR_MINI_V1 = WeActStudioDevice(
        id="B1",
        vid_pid="0x1A86:0xFE0C",
        cmd=b"\x41\xa5\xaa\x0a",
        user_string="POWERMONITORMV1",
    )

    @classmethod
    def get_supported_devices(cls):
        """Get all supported devices"""
        return [
            dev
            for dev in [cls.__dict__.values()]
            for dev in cls.__dict__.values()
            if isinstance(dev, WeActStudioDevice)
        ]

    @classmethod
    def get_device_info(cls, user_string: str):
        """Get device info for a specific device"""
        return next(
            (
                dev
                for dev in cls.get_supported_devices()
                if dev.user_string == user_string
            ),
            None,
        )


def find_device_port(device_vid_pid: str, device_id: str):
    """
    find device port by device_id
    :param device_vid_pid: device vid_pid, e.g. "0x1A86:0xFE0C"
    :param device_id: device id, e.g. "AA"
    :return: device port, e.g. "COM3"
    :raises: None
    """
    ports = list_ports.comports()

    try:
        target_vid, target_pid = device_vid_pid.split(":")
        target_vid = int(target_vid, 16)
        target_pid = int(target_pid, 16)
    except:
        print(f"[❌ ERROR] VID:PID format error, example: {device_vid_pid}")
        return None

    for port in ports:
        # print all ports, for debug
        # vid_hex = hex(port.vid) if port.vid is not None else "None"
        # pid_hex = hex(port.pid) if port.pid is not None else "None"
        # print(f"[DEBUG] Port: {port.device}, VID:PID: {vid_hex}:{pid_hex}, Serial Number: {port.serial_number}")

        # 1. no serial number, skip
        if not port.serial_number:
            continue

        # 2. check vid_pid
        if port.vid is None or port.pid is None:
            continue

        # 3. check vid_pid and if serial number contains device_id
        if port.vid == target_vid and port.pid == target_pid:
            if port.serial_number.upper().startswith(device_id.upper()):
                print(
                    f"[ℹ️ INFO] Found device port: {port.device} | VID:PID: {hex(port.vid)}:{hex(port.pid)} | Serial Number: {port.serial_number}"
                )
                return port.device

    # 4. no device found
    print(
        f"[WARNING ⚠️] No device found with vid_pid {device_vid_pid} and id {device_id}"
    )
    return None


def grant_port_permission(port: str):
    try:
        print(f"[ℹ️ INFO] Linux or macOS system: Setting permissions for {port}")
        # Set permissions to 666 (read/write for all users)
        subprocess.run(
            ["sudo", "chmod", "666", port],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        print(f"[✅ SUCCESS] Linux or macOS system: Permissions set OK for {port}")
    except Exception as e:
        print(
            f"[⚠️ WARNING] Linux or macOS system: Could not set permissions automatically: {e}"
        )
        print(
            f"[⚠️ INFO] Linux or macOS system: Please run manually: sudo chmod 666 {port}"
        )
        return False
    return True


def enter_upgrade_mode(port: str, cmd: bytes, baud=9600):
    ser = None

    is_send_cmd = False

    while True:
        # ===================== First Step: Try to read CC directly =====================
        try:
            ser = serial.Serial(port, baud, timeout=0.5)
            print(f"[ℹ️ INFO] Opening {port} to read upgrade mode response...")

            c_count = 0
            start_time = time.time()

            # check if already in upgrade mode, read 3 seconds
            while time.time() - start_time < 3:
                char = ser.read(1)
                if char == b"C":
                    c_count += 1
                    print(f"[ℹ️ INFO] Received C ({c_count}/2)")
                    if c_count >= 2:
                        print("[ℹ️ INFO] Device already in upgrade mode")
                        ser.close()
                        return True
                time.sleep(0.05)

            # no upgrade mode detected, close port and prepare to send command
            ser.close()
            print("[ℹ️ INFO] No upgrade mode detected, preparing to send command")

        except Exception as e:
            print(f"[❌ ERROR] Failed to open port: {e}")
            if ser:
                ser.close()
            return False

        if is_send_cmd:
            break

        # ===================== Second Step: Send command (device will restart) =====================
        try:
            ser = serial.Serial(port, baud, timeout=0.5)
            ser.write(cmd)
            print(
                "[ℹ️ INFO] Sending enter upgrade mode command, device will restart..."
            )
            ser.close()  # Must close port! Device will restart and disconnect
            is_send_cmd = True
        except:
            pass

        # for device to restart and enumerate port
        print(f"[ℹ️ INFO] Waiting for port {port} to enumerate...")
        time.sleep(3)
        timeout_time = time.time() + 3  # 3秒超时
        port_found = False

        while time.time() < timeout_time:
            ports = list_ports.comports()
            # Check if port is in the list
            if port in [p.device for p in ports]:
                port_found = True
                break
            time.sleep(0.5)

        if not port_found:
            print(f"[❌ ERROR] Timeout waiting for port {port}")
            return False
        else:
            print(f"[✅ SUCCESS] Port {port} found")

        if os.name == "posix":
            if not grant_port_permission(port):
                return False

    print("[❌ ERROR] Failed to enter upgrade mode")
    return False


class YModem:
    # Ymodem protocol constants
    SOH = b"\x01"  # 128-byte packet
    STX = b"\x02"  # 1024-byte packet (Ymodem 1K)
    EOT = b"\x04"  # End of transmission
    ACK = b"\x06"  # Acknowledge
    NAK = b"\x15"  # Negative acknowledge
    CAN = b"\x18"  # Cancel
    C = b"C"  # Handshake signal

    def __init__(self, port, baudrate=115200, timeout=3):
        """Initialize serial port for Ymodem"""
        self.ser = serial.Serial(
            port=port,
            baudrate=baudrate,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=timeout,
        )
        self.timeout = timeout
        if not self.ser.is_open:
            self.ser.open()
        print(f"[ℹ️ INFO] Serial port {port} opened successfully")

    def close(self):
        """Close serial port"""
        if self.ser.is_open:
            self.ser.close()
            print("[ℹ️ INFO] Serial port closed")

    def _crc16(self, data):
        """Calculate CRC16-CCITT (Ymodem standard)"""
        crc = 0x0000
        for byte in data:
            crc ^= byte << 8
            for _ in range(8):
                if crc & 0x8000:
                    crc = (crc << 1) ^ 0x1021
                else:
                    crc <<= 1
            crc &= 0xFFFF
        return crc

    def _read_byte(self):
        """Read single byte with timeout"""
        return self.ser.read(1)

    def _wait_for(self, expected, max_attempts=20):
        """Wait for expected response byte"""
        for _ in range(max_attempts):
            resp = self._read_byte()
            if resp == expected:
                return True
        return False

    def send_file(self, file_path):
        """Send a single file via Ymodem"""
        if not os.path.exists(file_path):
            print(f"[❌ ERROR] File not found: {file_path}")
            return False

        file_name = os.path.basename(file_path)
        file_size = os.path.getsize(file_path)
        print(f"[ℹ️ INFO] Starting Ymodem transfer: {file_name} ({file_size} bytes)")

        # Step 1: Wait for 'C' handshake from receiver
        print("[⏳ WAIT] Waiting for receiver 'C' handshake...")
        if not self._wait_for(self.C):
            print("[❌ ERROR] Timeout waiting for handshake 'C'")
            return False
        print("[ℹ️ INFO] Received handshake 'C'")

        # Step 2: Send header packet (00 packet: filename + size)
        header = file_name.encode() + b"\x00"
        header += str(file_size).encode() + b"\x00"
        header = header.ljust(128, b"\x00")  # Pad to 128 bytes
        crc = self._crc16(header)
        packet = (
            self.SOH
            + b"\x00"
            + b"\xff"
            + header
            + bytes([(crc >> 8) & 0xFF, crc & 0xFF])
        )

        self.ser.write(packet)
        if not self._wait_for(self.ACK):
            print("[❌ ERROR] Header packet ACK failed")
            return False
        print("[ℹ️ INFO] Header packet acknowledged")

        # Wait for second 'C' before data transfer
        if not self._wait_for(self.C):
            print("[❌ ERROR] Missing second handshake 'C'")
            return False

        # Step 3: Send file data packets (1K = STX)
        packet_num = 1
        with open(file_path, "rb") as f:
            while True:
                data = f.read(1024)
                if not data:
                    break

                # Prepare packet
                if len(data) < 1024:
                    data = data.ljust(1024, b"\x00")
                crc = self._crc16(data)
                packet = (
                    self.STX + bytes([packet_num]) + bytes([0xFF - packet_num]) + data
                )
                packet += bytes([(crc >> 8) & 0xFF, crc & 0xFF])

                total_packets = (file_size + 1023) // 1024

                # Send and wait for ACK
                self.ser.write(packet)
                if not self._wait_for(self.ACK):
                    print(f"[❌ ERROR] Packet {packet_num} failed")
                    return False

                total = total_packets
                progress = (packet_num / total) * 100
                bar_length = 30
                filled = int(bar_length * packet_num // total)
                bar = "█" * filled + " " * (bar_length - filled)

                print(
                    f"\r[⏳ PROGRESS] {bar} {progress:.1f}%  Packet {packet_num}/{total}",
                    end="",
                    flush=True,
                )
                packet_num += 1
        print("\r")

        # Step 4: Send EOT sequence
        print("[ℹ️ INFO] Sending EOT (End of Transmission)")
        self.ser.write(self.EOT)
        if not self._wait_for(self.NAK):
            print("[❌ ERROR] EOT NAK failed")
            return False

        self.ser.write(self.EOT)
        if not self._wait_for(self.ACK):
            print("[❌ ERROR] Final EOT ACK failed")
            return False

        # Step 5: Send closing empty packet
        empty = b"\x00" * 128
        crc = self._crc16(empty)
        final_pkt = (
            self.SOH
            + b"\x00"
            + b"\xff"
            + empty
            + bytes([(crc >> 8) & 0xFF, crc & 0xFF])
        )
        self.ser.write(final_pkt)
        self._wait_for(self.ACK)

        print(f"[✅ SUCCESS] Ymodem transfer completed: {file_name}")
        return True


if __name__ == "__main__":
    if getattr(sys, "frozen", False):
        APP_NAME = os.path.basename(sys.executable)
    else:
        APP_NAME = "python " + os.path.basename(sys.argv[0])

    if len(sys.argv) < 2 or len(sys.argv) > 3:
        print(f"Usage: {APP_NAME} [serial_port] <file_path>")
        print(f"Example 1 (Auto Search): {APP_NAME} firmware.fpk")
        print(f"Example 2 (Specify Port): {APP_NAME} COM30 firmware.fpk")
        sys.exit(1)

    if len(sys.argv) == 3:
        port = sys.argv[1]
        file = sys.argv[2]
    else:
        file = sys.argv[1]
        port = None

    print(f"[ℹ️ INFO] File Path: {file}")

    # 1. Read FPK header
    if not file.lower().endswith(".fpk"):
        print(f"[❌ ERROR] File is not a FPK file")
        sys.exit(1)
    fpk_header = FPK_HeaderReader()
    header = fpk_header.read_fpk_header(file)

    # 2. Print FPK header info
    print("[🔍 INFO] FPK File Header Info:")
    print(" " * 10 + f"Head Name      : {header['head_name']}")
    print(" " * 10 + f"Config Info    : {header['config_info']}")
    print(" " * 10 + f"FW Old Version : {header['fw_old_ver']}")
    print(" " * 10 + f"FW New Version : {header['fw_new_ver']}")
    print(" " * 10 + f"User String    : {header['user_string']}")
    print(" " * 10 + f"Part Name      : {header['part_name']}")
    print(" " * 10 + f"Raw Size       : {header['raw_size']} bytes")
    print(" " * 10 + f"Package Size   : {header['pkg_size']} bytes")
    print(" " * 10 + f"Timestamp      : {header['timestamp']}")
    print(" " * 10 + f"Raw CRC32      : {header['raw_crc32']}")
    print(" " * 10 + f"Package CRC32  : {header['pkg_crc32']}")
    print(" " * 10 + f"Header CRC32   : {header['head_crc32']}")

    # 3. Get FPK file device info
    print("[🔍 INFO] Get FPK file device info...")
    device_info = WeActStudioDeviceInfo.get_device_info(header["user_string"])
    if not device_info:
        print(f"[❌ ERROR] Device {header['user_string']} not supported")
        sys.exit(1)
    else:
        print(
            f"[ℹ️ INFO] Device {header['user_string']} {device_info.vid_pid} supported"
        )

    # 4. Find device port
    if not port:
        print(f"[🔍 INFO] Find device {header['user_string']} {device_info.vid_pid} port...")
        port = find_device_port(device_info.vid_pid, device_info.id)
        if not port:
            print(
                f"[❌ ERROR] Device {header['user_string']} {device_info.vid_pid} not found"
            )
            sys.exit(1)

        if os.name == "posix":
            if not grant_port_permission(port):
                sys.exit(1)

    # 5. Enter upgrade mode
    print("[🔍 INFO] Checking upgrade mode...")
    if not enter_upgrade_mode(port, device_info.cmd):
        print("[❌ ERROR] Failed to enter upgrade mode")
        sys.exit(1)

    # 6. Transfer file
    print("[🔍 INFO] Use YModem protocol transfer file...")
    ymodem = YModem(port)
    try:
        if ymodem.send_file(file):
            print("[🎉 SUCCESS] FPK File transfer completed")
        else:
            print("[❌ ERROR] FPK File transfer failed")
    except KeyboardInterrupt:
        print("\n[⚠️ WARNING] Transfer canceled by user")
    except Exception as e:
        print(f"[❌ ERROR] Transfer failed: {str(e)}")
    finally:
        ymodem.close()
    print("[🎉 INFO] Have a good day!")
